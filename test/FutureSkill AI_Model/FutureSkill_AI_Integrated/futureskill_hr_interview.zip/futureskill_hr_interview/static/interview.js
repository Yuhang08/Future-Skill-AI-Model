const $ = (id) => document.getElementById(id);
let sessionId = null;
let mediaRecorder = null;
let mediaStream = null;
let chunks = [];
let recording = false;
let currentQuestion = "";

function show(which) {
  for (const id of ["setup", "interview", "report"]) $(id).classList.toggle("hidden", id !== which);
}
function error(message="") { $("error").textContent = message; }
function loading(btn, yes) { btn.disabled = yes; }
async function api(path, options={}) {
  const response = await fetch(path, options);
  let body;
  try { body = await response.json(); } catch { throw new Error("Server returned an unexpected response."); }
  if (!response.ok) throw new Error(body.error || "Something went wrong.");
  return body;
}
function jsonPost(path, obj) { return api(path, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(obj)}); }
function setQuestion(data) {
  currentQuestion = data.question;
  $("questionText").textContent = data.question;
  $("focusText").textContent = "Focus: " + (data.focus || "Interview practice");
  $("counter").textContent = `Question ${data.question_number} of ${data.max_questions || 5}`;
  $("answer").value = "";
  $("feedbackBox").classList.add("hidden");
  $("submit").disabled = false;
  $("record").disabled = false;
}
function bars(scores, mount) {
  mount.replaceChildren();
  for (const [name, value] of Object.entries(scores)) {
    const row = document.createElement("div"); row.className = "barrow";
    const label = document.createElement("span"); label.textContent = name[0].toUpperCase() + name.slice(1);
    const bar = document.createElement("div"); bar.className = "bar";
    const fill = document.createElement("div"); fill.className = "fill"; fill.style.width = `${Math.max(0,Math.min(100,value))}%`;
    const num = document.createElement("span"); num.textContent = Math.round(value) + "%";
    bar.append(fill); row.append(label,bar,num);mount.append(row);
  }
}
function fillList(id, values) { $(id).replaceChildren(); for (const v of values) { const li=document.createElement("li");li.textContent=v;$(id).append(li); } }
$("start").addEventListener("click", async () => {
  error(); loading($("start"),true);
  try {
    const role=$("role").value, mode=$("mode").value, language=$("language").value;
    const data=await jsonPost("/api/interview/start",{role,mode,language});
    sessionId=data.session_id;$("careerLabel").textContent=`${role} · ${mode}`;
    setQuestion(data);show("interview");
  } catch(e){error(e.message);} finally {loading($("start"),false);}
});
$("speak").addEventListener("click", () => {
  if (!("speechSynthesis" in window)) { error("Browser speech playback is unavailable."); return; }
  window.speechSynthesis.cancel();const msg=new SpeechSynthesisUtterance(currentQuestion);
  msg.lang=$("language").value==="中文"?"zh-CN":"en-US";msg.rate=.95;window.speechSynthesis.speak(msg);
});
$("record").addEventListener("click", async () => {
  error();
  if (recording) {mediaRecorder.stop();return;}
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {error("Microphone recording not supported by this browser. You can type your answer.");return;}
  try {
    mediaStream=await navigator.mediaDevices.getUserMedia({audio:true});
    const candidates=["audio/webm;codecs=opus","audio/webm","audio/mp4","audio/ogg"];
    const mime=candidates.find(t=>MediaRecorder.isTypeSupported(t));
    if(!mime) throw new Error("No supported recording format. Please type your answer.");
    mediaRecorder=new MediaRecorder(mediaStream,{mimeType:mime});chunks=[];
    mediaRecorder.ondataavailable=(e)=>{if(e.data.size)chunks.push(e.data);};
    mediaRecorder.onstop=async()=>{
      recording=false;$("record").textContent="🎙 Start Recording";$("recordStatus").textContent="Transcribing...";
      mediaStream?.getTracks().forEach(t=>t.stop());
      const blob=new Blob(chunks,{type:mime});
      if(!blob.size){error("No audio captured.");$("recordStatus").textContent="";return;}
      if(blob.size>10*1024*1024){error("Audio too large (10 MB limit). Record a shorter answer.");$("recordStatus").textContent="";return;}
      $("record").disabled=true;
      try {
        const form=new FormData();form.append("session_id",sessionId);form.append("audio",blob,"answer."+(mime.includes("mp4")?"mp4":mime.includes("ogg")?"ogg":"webm"));
        const data=await api("/api/interview/transcribe",{method:"POST",body:form});
        $("answer").value=($("answer").value.trim()+" "+data.transcript).trim();
      } catch(e){error(e.message);}finally{$("record").disabled=false;$("recordStatus").textContent="";}
    };
    mediaRecorder.start(); recording=true; $("record").textContent="⏹ Stop Recording";$("recordStatus").textContent="Recording...";
  } catch(e){mediaStream?.getTracks().forEach(t=>t.stop());error(e.message);}
});
$("submit").addEventListener("click",async()=>{
  error();if(recording){error("Stop recording first.");return;}
  const answer=$("answer").value.trim();if(answer.length<3){error("Please enter a longer answer.");return;}
  loading($("submit"),true);
  try {
    const data=await jsonPost("/api/interview/feedback",{session_id:sessionId,answer});
    const f=data.feedback;$("totalScore").textContent=f.total+" / 100 · Practice score";
    $("summary").textContent=f.summary;bars(f.scores,$("dimensions"));
    fillList("strengths",f.strengths);fillList("improvements",f.improvements);
    $("example").textContent=f.example_answer;
    $("next").textContent=data.finished?"View final report →":"Next question →";
    $("feedbackBox").classList.remove("hidden");
  }catch(e){error(e.message);loading($("submit"),false);}
});
function presentReport(rep) {
  $("reportIntro").textContent=`${rep.role} · ${rep.questions_completed} question(s) completed`;
  $("finalScore").textContent=`${rep.overall} / 100 · Average practice score`;
  bars(rep.average_dimensions,$("reportDimensions"));
  fillList("priorities",rep.practice_priorities.map(x=>`Focus your next practice on ${x}.`));
  $("history").replaceChildren();
  rep.history.forEach((item,i)=>{
    const div=document.createElement("div");div.className="historyItem";
    const title=document.createElement("strong");title.textContent=`Q${i+1}: ${item.question}`;
    const ans=document.createElement("p");ans.textContent=`Your answer: ${item.answer}`;
    const sc=document.createElement("p");sc.textContent=`Practice score: ${item.feedback.total}/100`;
    const improvement=document.createElement("p");improvement.textContent=`Improve: ${item.feedback.improvements.join(" · ")}`;
    div.append(title,ans,sc,improvement);$("history").append(div);
  });
  sessionId=null;show("report");
}
$("next").addEventListener("click",async()=>{
  error();loading($("next"),true);
  try {const data=await jsonPost("/api/interview/next",{session_id:sessionId});
    if(data.finished)presentReport(data.report);else setQuestion({...data,max_questions:5});
  }catch(e){error(e.message);}finally{loading($("next"),false);}
});
$("finishEarly").addEventListener("click",async()=>{
  error();loading($("finishEarly"),true);
  try {const data=await jsonPost("/api/interview/end",{session_id:sessionId});presentReport(data.report);}
  catch(e){error(e.message);}finally{loading($("finishEarly"),false);}
});
$("restart").addEventListener("click",()=>{sessionId=null;error();show("setup");});
