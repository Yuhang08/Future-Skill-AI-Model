"""FutureSkill AI HR interview demo. In-memory sessions: one worker for MVP."""
import os
import threading
import time
import uuid
from flask import Flask, jsonify, render_template, request
from dotenv import load_dotenv
from interview_engine import initial_question, feedback_for, next_question, report
from speech_service import transcribe

load_dotenv()
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 11 * 1024 * 1024
sessions = {}
lock = threading.RLock()
MAX_QUESTIONS = 5
TTL = 60 * 60
ROLES = {"Data Scientist", "Software Engineer", "AI Engineer", "Business Analyst", "Cybersecurity Analyst", "Other"}
MODES = {"HR", "Technical", "Mixed"}
LANGUAGES = {"English", "中文"}


def error(message, status=400):
    return jsonify({"error": message}), status


def current_session(data):
    sid = str(data.get("session_id", ""))
    with lock:
        session = sessions.get(sid)
        if session and time.time() - session["created"] > TTL:
            sessions.pop(sid, None)
            session = None
    return sid, session


@app.errorhandler(413)
def too_large(_):
    return error("Audio file is too large (maximum 10 MB).", 413)


@app.get("/")
def home():
    return render_template("interview.html")


@app.post("/api/interview/start")
def start():
    data = request.get_json(silent=True) or {}
    role = str(data.get("role", ""))
    mode = str(data.get("mode", "Mixed"))
    language = str(data.get("language", "English"))
    if role not in ROLES or mode not in MODES or language not in LANGUAGES:
        return error("Invalid career, mode, or language.")
    if not os.getenv("OPENAI_API_KEY"):
        return error("Server missing OPENAI_API_KEY configuration.", 503)
    try:
        question = initial_question(role, mode, language)
    except Exception:
        app.logger.exception("Initial question failed")
        return error("Could not generate the first question. Please retry.", 503)
    sid = uuid.uuid4().hex
    with lock:
        # Small demo-only session store; expired records removed periodically.
        for key, value in list(sessions.items()):
            if time.time() - value["created"] > TTL:
                sessions.pop(key, None)
        sessions[sid] = {"created": time.time(), "role": role, "mode": mode, "language": language,
                         "question": question, "history": [], "awaiting_next": False}
    return jsonify({"session_id": sid, "question_number": 1, "max_questions": MAX_QUESTIONS, **question})


@app.post("/api/interview/transcribe")
def audio_to_text():
    sid, session = current_session(request.form)
    if not session:
        return error("Interview session expired or not found.", 404)
    upload = request.files.get("audio")
    if not upload:
        return error("No audio uploaded.")
    try:
        text = transcribe(upload)
        return jsonify({"transcript": text})
    except ValueError as exc:
        return error(str(exc))
    except Exception:
        app.logger.exception("Transcription failed")
        return error("Speech transcription failed. Try typing your answer.", 503)


@app.post("/api/interview/feedback")
def feedback():
    data = request.get_json(silent=True) or {}
    sid, session = current_session(data)
    if not session:
        return error("Interview session expired or not found.", 404)
    answer = str(data.get("answer", "")).strip()
    if not (3 <= len(answer) <= 3500):
        return error("Please enter an answer between 3 and 3500 characters.")
    with lock:
        if session["awaiting_next"] or len(session["history"]) >= MAX_QUESTIONS:
            return error("This question was already submitted.", 409)
        # Set flag before costly model call to reduce accidental double submissions.
        session["awaiting_next"] = True
        question = session["question"]["question"]
    try:
        result = feedback_for(question, answer, session["role"], session["mode"], session["language"])
    except Exception:
        with lock:
            session["awaiting_next"] = False
        app.logger.exception("Feedback failed")
        return error("Could not evaluate the answer. Please retry.", 503)
    with lock:
        session["history"].append({"question": question, "answer": answer, "feedback": result})
        finished = len(session["history"]) >= MAX_QUESTIONS
    return jsonify({"feedback": result, "finished": finished})


@app.post("/api/interview/next")
def next_q():
    data = request.get_json(silent=True) or {}
    sid, session = current_session(data)
    if not session:
        return error("Interview session expired or not found.", 404)
    with lock:
        if not session["awaiting_next"]:
            return error("Submit an answer before proceeding.", 409)
        if len(session["history"]) >= MAX_QUESTIONS:
            return jsonify({"finished": True, "report": report(session["history"], session["role"])})
        history = list(session["history"])
    try:
        question = next_question(session["role"], session["mode"], session["language"], history)
    except Exception:
        app.logger.exception("Next question failed")
        return error("Could not generate the next question. Please retry.", 503)
    with lock:
        session["question"] = question
        session["awaiting_next"] = False
    return jsonify({"finished": False, "question_number": len(history) + 1, **question})


@app.post("/api/interview/end")
def end():
    data = request.get_json(silent=True) or {}
    sid, session = current_session(data)
    if not session:
        return error("Interview session expired or not found.", 404)
    with lock:
        if not session["history"]:
            return error("Answer at least one question first.")
        result = report(session["history"], session["role"])
        sessions.pop(sid, None)
    return jsonify({"report": result})


if __name__ == "__main__":
    app.run(debug=False, port=5000)
