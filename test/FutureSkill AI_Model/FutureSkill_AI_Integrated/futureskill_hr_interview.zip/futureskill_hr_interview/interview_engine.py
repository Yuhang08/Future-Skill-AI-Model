"""LLM question and feedback engine. All score ranges are coaching heuristics."""
import json
import os
from openai import OpenAI

MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
_client = None


def client():
    global _client
    if _client is None:
        _client = OpenAI(timeout=40.0, max_retries=1)
    return _client


def llm_json(instructions, payload):
    response = client().responses.create(
        model=MODEL,
        instructions=instructions + "\nReturn only a valid JSON object, no markdown fences.",
        input=json.dumps(payload, ensure_ascii=False),
        text={"format": {"type": "json_object"}},
        max_output_tokens=1100,
        store=False,
    )
    return json.loads(response.output_text)


def initial_question(role, mode, language):
    result = llm_json(
        "You are a supportive and professional mock interviewer. Create one realistic first interview question "
        "for the specified career and mode. Do not ask for sensitive personal details. "
        'Return JSON {"question":"...","focus":"..."}. Use the requested language.',
        {"role": role, "mode": mode, "language": language},
    )
    return {"question": str(result["question"])[:600], "focus": str(result.get("focus", "General communication"))[:200]}


def feedback_for(question, answer, role, mode, language):
    result = llm_json(
        "Evaluate the *content* of a mock interview answer as a coach. Avoid assessing accent, appearance, "
        "identity or suitability for employment. Do not pretend a simulated score predicts hiring. "
        "Do not invent the candidate's experiences. Evaluate using these coaching dimensions scored 0-100: "
        "relevance, clarity, evidence, depth, language. Language means understandable wording, not accent. "
        "If the response is too brief to assess, give low evidence/depth scores and explain gently. "
        "Scores are subjective practice heuristics, not scientific measurements. "
        'Return JSON with fields "scores" (an object with keys relevance,clarity,evidence,depth,language and integer values), '
        '"strengths" (array of 1-3 short strings), "improvements" (array of 2-3 actionable strings), '
        '"example_answer" (a clearly fictional illustrative sample answer), "summary" (one sentence). '
        "Use the requested language for human-readable feedback.",
        {"question": question, "answer": answer, "role": role, "mode": mode, "language": language},
    )
    names = ("relevance", "clarity", "evidence", "depth", "language")
    scores = {}
    for key in names:
        try:
            scores[key] = max(0, min(100, int(result.get("scores", {}).get(key, 0))))
        except (TypeError, ValueError):
            scores[key] = 0
    total = round(sum(scores[k] * w for k, w in zip(names, (0.30, 0.25, 0.20, 0.15, 0.10))), 1)
    return {
        "scores": scores,
        "total": total,
        "strengths": [str(x)[:300] for x in result.get("strengths", [])[:3]],
        "improvements": [str(x)[:350] for x in result.get("improvements", [])[:3]],
        "example_answer": str(result.get("example_answer", ""))[:1600],
        "summary": str(result.get("summary", ""))[:500],
    }


def next_question(role, mode, language, history):
    history_compact = [
        {"question": x["question"], "answer": x["answer"][:650], "feedback_summary": x["feedback"]["summary"]}
        for x in history[-3:]
    ]
    result = llm_json(
        "You are a supportive mock HR interviewer. Write exactly one NEW interview question, sometimes as a "
        "relevant follow-up to a previous answer. Avoid asking the same question twice, or soliciting sensitive data. "
        'Return JSON {"question":"...","focus":"..."} in requested language.',
        {"role": role, "mode": mode, "language": language, "history": history_compact},
    )
    return {"question": str(result["question"])[:600], "focus": str(result.get("focus", ""))[:200]}


def report(history, role):
    keys = ("relevance", "clarity", "evidence", "depth", "language")
    averages = {k: round(sum(x["feedback"]["scores"][k] for x in history) / len(history), 1) for k in keys}
    return {
        "role": role,
        "questions_completed": len(history),
        "overall": round(sum(x["feedback"]["total"] for x in history) / len(history), 1),
        "average_dimensions": averages,
        "practice_priorities": sorted(keys, key=lambda k: averages[k])[:2],
        "history": history,
        "disclaimer": "These are AI coaching estimates, not validated hiring predictions.",
    }
