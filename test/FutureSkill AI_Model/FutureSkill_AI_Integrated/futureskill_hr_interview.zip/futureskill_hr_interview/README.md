# FutureSkill AI — HR Mock Interview

A standalone Flask demo with role-specific AI questions, microphone recording and transcription, question-by-question feedback, adaptive follow-ups, and a final practice report.

## Run locally (PyCharm)

1. Open this folder as a project.
2. Create a Python virtual environment.
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and add your own OpenAI API key. Never commit `.env`.
5. `python app.py`
6. Open http://127.0.0.1:5000/ and allow microphone access if you want voice input.

## Deploy to Render

- Push files to your repository, excluding `.env`.
- Python web service build command: `pip install -r requirements.txt`
- Start command: `gunicorn -w 1 app:app`
- Add `OPENAI_API_KEY` in Render Environment, and optionally `OPENAI_MODEL=gpt-4.1-mini`.
- Deploy. HTTPS is required for microphone recording outside localhost.

## Integrate into existing FutureSkill AI Flask app

Do **not** replace your existing `app.py`. Copy `interview_engine.py`, `speech_service.py`, `templates/interview.html`, `static/interview.js`, and `static/interview.css`.
Then transplant the `/api/interview/...` Flask routes (and module imports + session store) from this demo into your original Flask app, and change the interview page route to `/interview`. Add a link from your homepage to `/interview`.

If you want to pull recommended careers from `career_engine.py`, replace the fixed `ROLES` allowlist with **server-side validated** roles from your career dataset. Never accept a client-provided matching score as fact.

## Limitations & safety

- Uses paid OpenAI API calls; ChatGPT subscription is separate.
- Five questions/session; temporary RAM sessions expire after 60 minutes and are lost on server restart. Render: use **one worker** for this MVP. For production replace dict sessions with Redis/DB, add account authentication, rate limiting, CSRF controls, consent, deletion, and spend controls.
- Audio sent to transcription API, not stored by this server; text answer and feedback remain in RAM for up to 60 minutes (or until ending early).
- Voice playback uses the browser's built-in SpeechSynthesis, not a paid TTS model. Voice input is recording → upload → transcript, **not full duplex real-time conversation**.
- Interview rubric scores are AI-generated coaching heuristics, not validated hiring assessments; do not assess accents, identity or appearance.
- `Other` is a generic role, not a custom text field. Extend validated role choices if needed.
